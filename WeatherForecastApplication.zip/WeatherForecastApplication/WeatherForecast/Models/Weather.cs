﻿namespace WeatherForecast.Models
{
    public class Weather
    {
        public string icon { get; set; }
    }
}
