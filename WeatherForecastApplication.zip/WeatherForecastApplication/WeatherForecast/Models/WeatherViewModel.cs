﻿namespace WeatherForecast.Models
{
    public class WeatherViewModel
    {
        public string Country {  get; set; }
        public string City { get; set; }
        public string Temperatute { get; set; }
        public string icon { get; set; }

    }
}
