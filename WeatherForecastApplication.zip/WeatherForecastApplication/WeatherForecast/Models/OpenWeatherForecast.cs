﻿namespace WeatherForecast.Models
{
    public class OpenWeatherForecast
    {
        public List<ForecastItem> list { get; set; }
    }
}
